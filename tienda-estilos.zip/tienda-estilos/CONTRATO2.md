# Contrato v2 (cambios sobre CONTRATO.md; lo no mencionado se mantiene)

## API del servidor (server.js, persistencia en data/db.json, sin dependencias; lo escribe el agente SERVIDOR)
Seed al primer arranque: carga js/data.js con `vm` (window=globalThis simulado) y vuelca todos los cortes de CATALOG.getCuts a `db.products`.
Producto = corte: `{id, styleId, typeId, name, price, image:null|dataURL|url, colors:[{id,name,hex}], active:true}`; ids únicos.
Cuenta: `{id,name,email,phone?,passwordHash(scrypt+salt),sizes:{[typeId]:size},createdAt,lastLogin,loginCount}`.
Código: `{code (MAYÚSCULAS, único), kind:'outfit'|'discount', description, percent (discount 1-90), items:[{styleId,typeId,cutId,colorId}] (outfit), active:true}`. Seed: `LOOK-DEMO` (outfit con 3 piezas reales) y `DESC10` (10%).

Públicos:
- `GET /api/catalog` -> `{products:[solo active], gallery}`.
- `POST /api/register {name,email,password,phone?}` -> `{ok,account(sin hash),token}`; `POST /api/login {email,password}` -> igual; error 401/409 `{ok:false,error}`.
- `GET /api/me` (header `Authorization: Bearer token`) -> cuenta; `PUT /api/me {name?,phone?,sizes?}` guarda datos y tallas.
- `GET /api/codes/:code` -> código activo o 404.
Admin (header `Authorization: Bearer <adminToken>`), login `POST /api/admin/login {user,password}` (credenciales por defecto admin / admin123, configurables por env ADMIN_USER/ADMIN_PASS; imprimir al arrancar):
- `GET /api/admin/accounts` (todos los datos, sin hash).
- `GET/POST /api/admin/products`, `PUT/DELETE /api/admin/products/:id` (DELETE = baja lógica `active:false`; PUT con active:true = alta). Body acepta `image` dataURL (límite 5MB, body JSON hasta 8MB).
- `GET/POST /api/admin/codes`, `PUT/DELETE /api/admin/codes/:code`.
Tokens en memoria + persistidos en db. Archivos estáticos igual que antes; `/admin` sirve admin.html.

## Panel admin (admin.html + js/admin.js + css propio en css/admin.css; agente SERVIDOR)
Login admin; pestañas: **Cuentas** (tabla con todos los datos: nombre, correo, teléfono, tallas, alta, último acceso, nº de accesos), **Productos** (tabla filtrable por estilo/tipo/estado; formulario para crear/editar: nombre del corte, estilo (select), tipo de prenda (select), precio, colores (agregar/quitar nombre+hex), imagen (input file -> dataURL con vista previa); botones Alta/Baja), **Códigos** (crear/editar/baja códigos de atuendo eligiendo piezas con selects estilo/tipo/corte/color, y códigos de descuento %).

## Tienda — data.js / store.js (agente DATOS)
- `CATALOG.load()` -> Promise: hace fetch `/api/catalog`; si OK reemplaza la fuente de `getCuts/getCut` por los productos del servidor (cortes con `image`) y `gallery`; si falla usa el generador actual. Debe además exponer `CATALOG.allColors(styleId,typeId,cutId)` (= colores del corte) y `CATALOG.cutImage(cut,style)` (image del producto o imgSVG).
- Cuentas reales: `Store.register({name,email,password,phone})`, `Store.login({email,password})` ambos async -> `{ok,error}`; guardan `token` y cuenta en state.profile (`profile.token`). Al iniciar sesión se cargan las tallas de la cuenta desde el servidor; `setProfileSize` con sesión hace `PUT /api/me`. `Store.logout()`. Si hay token al cargar, refrescar con `GET /api/me`. **Las tallas del perfil deben respetarse:** `missingSizesForCheckout` solo pide tallas que de verdad faltan; `checkout()` con sesión sincroniza al servidor.
- `Store.toggleColor(styleId,typeId,cutId,colorId)` -> agrega si no está, quita si está (sin cambiar de pantalla) y devuelve `{added:boolean}`.
- `Store.effectiveSize(item)` -> talla que se compra: `item.size` si forOther, si no `profile.sizes[typeId]` o null.
- Códigos: `Store.applyCode(code)` async -> `{ok,error?,kind}`. Outfit: agrega esas piezas (ignora duplicados/inactivas) y guarda `state.codes`; discount: guarda `state.discount={code,percent}`. `Store.removeDiscount()`. `Store.totals()` -> `{subtotal,discount,total}`. checkout usa total con descuento.
- `Store.combinations()` se mantiene (lógica interna de recomendaciones), pero la UI NO debe mostrarlo.

## UI — app.js / css/app.css / index.html (agente UI)
1. Antes de `route()` esperar `CATALOG.load()`.
2. Carrito: botón **“← Volver a tipos de prenda”** (a `#/estilo/<lastStyle o estilo del último ítem>`). 
3. Pantalla de tipos de prenda: botón **“Cambio de estilo”** que lleva a `#/` (main).
4. Carrito: por cada corte mostrar **TODOS los colores posibles del corte** como chips/swatches; tocar un color lo agrega (`Store.toggleColor`), tocarlo de nuevo lo quita; estado seleccionado claramente visible; sin cambiar de pantalla.
5. **Eliminar de la UI el cálculo/desglose de “looks/combinaciones posibles”** (carrito, recomendaciones, etc.). Las recomendaciones siguen (tipo con menos piezas) pero SIN mostrar “+N combinaciones”; mostrar la prenda y su precio.
6. En el carrito, por corte mostrar la **talla que se compra** (`Store.effectiveSize`) por color/pieza; editable para forOther; si no hay talla de perfil, indicar “Falta tu talla” con selector que la guarda al perfil.
7. Inicio de sesión útil: modal con pestañas Iniciar sesión / Crear cuenta (nombre, correo, teléfono opcional, contraseña); perfil con datos y tallas guardadas que persisten entre sesiones; mensajes de error. Tallas no obligatorias para registrarse.
8. Campo en el carrito “Código de atuendo o descuento” + botón Aplicar; muestra mensajes, el descuento aplicado (con quitar) y subtotal/total.
9. Mostrar `cutImage` del producto en las tarjetas de corte si tiene imagen.

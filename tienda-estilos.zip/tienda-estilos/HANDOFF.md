# HANDOFF — Tienda de ropa por estilos ("Tienda por estilos")

Documento de traspaso para quien vaya a **publicar y/o continuar** este proyecto. Está escrito para que no haga falta preguntarle nada al autor original. Todo lo que aquí se afirma fue leído del código o probado; lo que **no** se probó está marcado como tal en la sección 14.

> **Aviso de seguridad para el dueño:** NO publiques esto dentro del proyecto de Vercel que ya usas para otra página. Crea un proyecto/cuenta nuevo e independiente (ver sección 10). Además, el panel admin viene con contraseña de prueba (`admin123`): hay que cambiarla antes de publicar (sección 9).

---

## 1. Qué es

Tienda en línea (demo funcional) de ropa organizada por **estilos**. El cliente navega por una cadena de filtros y al final arma un carrito de piezas (corte + color). Incluye cuentas de usuario con tallas guardadas, códigos de atuendo y de descuento, y un panel de administrador.

- **Frontend:** HTML + CSS + JavaScript "vanilla" (sin framework, sin build, sin npm install). Una sola página (SPA) con router por `#hash`.
- **Backend:** un único archivo `server.js` en Node.js (sin dependencias externas) que sirve los archivos estáticos y una API JSON. Guarda todo en un archivo `data/db.json`.
- **Idioma de la interfaz:** español (México). Moneda: pesos (`$`).
- **Sin pagos reales.** "Finalizar compra" solo vacía el carrito y muestra "¡Gracias por tu compra!". No se guardan pedidos (ver sección 14).

## 2. Requisitos originales del cliente (fuente de verdad)

Textuales de la descripción del cliente, resumidos fielmente. Cada punto abajo está implementado (columna "Dónde").

### Ronda 1 — Creación del producto
| # | Requisito | Dónde |
|---|---|---|
| 1 | Home: imagen aesthetic de fondo, 5 estilos de vestimenta, a su derecha una foto de ejemplo de cada estilo | `pageHome()` en `js/app.js` |
| 2 | Debajo, más imágenes de modelos con distintos estilos; al picar una se abre ese estilo | franja `.strip` en `pageHome()`, datos en `CATALOG.gallery` |
| 3 | Botón **arriba a la izquierda** de inicio de sesión; botón **abajo a la izquierda** de carrito (fijos en todas las pantallas) | `#btn-login`, `#btn-cart` en `index.html`; CSS `.fab-login`, `.fab-cart` |
| 4 | Primer filtro = estilo. Segundo filtro = tipo de prenda (playeras, pantalones, zapatos, sudaderas, chamarras, accesorios) | `pageStyle()` |
| 5 | Tercer filtro = tipo de corte dentro del tipo y estilo (corte recto, skinny, etc.) | `pageCuts()` |
| 6 | Al elegir corte salen los colores disponibles; elegidos, botón "Agregar al carrito" o "Comprar ahora" | `pageCut()` |
| 7 | Tras agregar prendas vuelve al filtro de tipo de prenda con los productos ya en el carrito | `addFromCut()` → `#/estilo/<s>` con insignia de piezas |
| 8 | Si ya hay mínimo 1 producto de **cada** tipo, en lugar de volver a tipos abre el carrito | `addFromCut()` usa `Store.hasAllTypes()` |
| 9 | El carrito (botón) siempre accesible abajo a la izquierda | `#btn-cart` |
| 10 | Carrito: en lugar de prenda por prenda, muestra cada **corte elegido** con los **colores palomeados** | `pageCart()` |
| 11 | Recomendaciones: artículos del **tipo con menos piezas**, dentro del estilo, de cualquier corte | `Store.recommendations()` |
| 12 | Perfil: correo, datos y **tallas** del usuario; las tallas se recaban con la primera compra o completando el perfil, **no son requisito para iniciar sesión**, solo para comprar artículos de cada tipo | `openLogin()`, `pageProfile()`, `openCheckout()` |
| 13 | Opción "comprar para alguien más": cada prenda con esa opción debe rellenar la talla | `pageCut()` (toggle + talla), `pageCart()` (por pieza), `openCheckout()` |

> En la ronda 1 se pidió también mostrar la **cantidad de combinaciones posibles** (producto de las cantidades por tipo, mínimo 1) y la diferencia en las recomendaciones. **En la ronda 2 el cliente pidió quitarlo de la pantalla** (ver abajo). La función `Store.combinations()` sigue existiendo en el código porque `recommendations()` la usa internamente, pero **no debe mostrarse** en ningún lado.

### Ronda 2 — Cambios pedidos
| # | Requisito | Dónde |
|---|---|---|
| A | Botón de regreso del carrito al filtro de tipo de prenda | `#btn-back-types` en `pageCart()` |
| B | En el filtro de tipo de prenda, botón al main que diga **"Cambio de estilo"** | `#btn-change-style` en `pageStyle()` |
| C | En el carrito salen **todos los colores posibles** de esa prenda y se agregan/quitan con solo tocar el color | chips `.swb` + `Store.toggleColor()` |
| D | No mostrar el cálculo de looks/combinaciones posibles | eliminado de `app.js` |
| E | Inicio de sesión **útil** (cuentas reales con contraseña, datos y tallas persistentes) | `/api/register`, `/api/login`, `/api/me`; `Store.register/login` |
| F | Panel de administrador: cuentas registradas con todos sus datos | `admin.html` pestaña **Cuentas** |
| G | Panel de administrador: productos (elegir todo: colores, tipo de prenda, estilo; alta y baja; imagen del producto) | pestaña **Productos** |
| H | Respetar las tallas que ya tiene el usuario (no volver a pedirlas) | `missingSizesForCheckout()`, `effectiveSize()` |
| I | En el carrito, por corte, mostrar la talla con la que se compra (la del perfil) | `.size-tag` en `pageCart()` |
| J | Códigos de **atuendo**: se escriben en el carrito y agregan automáticamente las prendas ligadas; se editan desde el admin | `Store.applyCode()` + pestaña **Códigos** |
| K | Códigos de **descuento** | `kind: 'discount'` |

## 3. Cómo correrlo en local (2 minutos)

Requisito: Node.js 18+ (se probó con v25). No hay `npm install`.

```bash
cd <carpeta-del-proyecto>
node server.js
# Tienda:  http://localhost:5173
# Admin:   http://localhost:5173/admin   (admin / admin123 por defecto)
```

Variables de entorno opcionales: `PORT` (default 5173), `ADMIN_USER` (default `admin`), `ADMIN_PASS` (default `admin123`).

Al primer arranque, `server.js` crea `data/db.json` cargando `js/data.js` con el módulo `vm` y volcando los 115 productos del catálogo base, más 2 códigos de ejemplo. **Si cambias `js/data.js` después, borra `data/db.json`** para que se vuelva a sembrar (esto borra cuentas y cambios hechos en el admin).

## 4. Mapa de archivos

```
index.html          Shell de la tienda: botones fijos, <main id="app">, carga 3 scripts
admin.html          Shell del panel admin (se sirve en /admin)
server.js           Servidor HTTP + API + persistencia en data/db.json (307 líneas)
css/app.css         Estilos de la tienda (tema oscuro, responsive, ~175 líneas)
css/admin.css       Estilos del panel admin
js/data.js          Catálogo base generado + CATALOG.load() que usa /api/catalog
js/store.js         Estado (carrito, perfil, descuento) + llamadas a la API (~260 líneas)
js/app.js           Todas las pantallas, router, modales (~485 líneas)
js/admin.js         Panel de administrador (~215 líneas)
CONTRATO.md         Contrato de diseño ronda 1 (referencia histórica)
CONTRATO2.md        Contrato de diseño ronda 2 (referencia histórica)
HANDOFF.md          Este documento
data/db.json        (se genera solo; NO subir a git, contiene cuentas)
```

Orden de carga en `index.html`: `js/data.js` → `js/store.js` → `js/app.js`. Cada uno cuelga de `window`: `window.CATALOG`, `window.imgSVG`, `window.Store`.

## 5. Modelo de datos

Todo está en `data/db.json`: `{ products, gallery, accounts, tokens, codes }`.

**Estilos (5, fijos en código, `CATALOG.styles`)**: `streetwear`, `minimal`, `vintage`, `deportivo`, `elegante`. Cada uno `{id, name, tagline, colors:[c1,c2,c3]}`.

**Tipos de prenda (6, fijos en código, `CATALOG.types`)**: `playeras`, `pantalones`, `zapatos`, `sudaderas`, `chamarras`, `accesorios`.

> Estilos y tipos **no** se editan desde el admin: están en `js/data.js`. Agregar un estilo o tipo nuevo requiere tocar código (ver sección 13).

**Producto = "corte"** (un registro por corte de una prenda en un estilo):
```json
{
  "id": "streetwear-playeras-oversize",
  "styleId": "streetwear", "typeId": "playeras",
  "name": "Oversize", "price": 349,
  "image": null,
  "colors": [{ "id": "negro", "name": "Negro", "hex": "#111111" }],
  "active": true
}
```
- `image`: `null`, un `data:image/...;base64,...` (hasta 5 MB) o una URL `http(s)://` o ruta que empiece por `/`. Si es `null` la tienda dibuja una ilustración SVG generada (`imgSVG`).
- `active:false` = "baja" (borrado lógico; nunca se borra el registro).
- El catálogo base genera 3–4 cortes por cada combinación estilo×tipo (115 en total) con 3–5 colores cada uno.

**Cuenta**:
```json
{ "id":"…", "name":"…", "email":"…(minúsculas)", "phone":"", "passwordHash":"salt:scrypt",
  "sizes": { "playeras":"M", "zapatos":"27" }, "createdAt":"ISO", "lastLogin":"ISO", "loginCount":1 }
```
Contraseñas con `crypto.scryptSync` + sal aleatoria de 16 bytes, comparación con `timingSafeEqual`. **Nunca** se devuelve `passwordHash` por la API (`pub()` lo quita).

**Código**:
```json
{ "code":"LOOK-DEMO", "kind":"outfit", "description":"…", "percent":0,
  "items":[{ "styleId":"streetwear","typeId":"playeras","cutId":"streetwear-playeras-oversize","colorId":"negro" }],
  "active":true }
{ "code":"DESC10", "kind":"discount", "description":"10% de descuento", "percent":10, "items":[], "active":true }
```
Reglas: código en MAYÚSCULAS `[A-Z0-9_-]{2,40}`; descuento de 1 a 90 %; atuendo con ≥ 1 pieza. En atuendos `cutId` es el **id del producto** (no el nombre).

**Tallas** (`CATALOG.sizes`): ropa `XS S M L XL XXL`; zapatos `24…30`; accesorios `Única`.

**Tokens**: `db.tokens[token] = {kind:'user'|'admin', id, created}`. **No expiran** (ver sección 14).

## 6. API HTTP (todo JSON)

Errores: `{ "ok": false, "error": "mensaje en español" }` con código 400/401/404/409/413/500.

Públicos
| Método y ruta | Cuerpo | Respuesta |
|---|---|---|
| `GET /api/catalog` | – | `{products:[solo activos], gallery}` |
| `POST /api/register` | `{name,email,password(≥6),phone?}` | `{ok,account,token}` · 409 si el correo existe |
| `POST /api/login` | `{email,password}` | `{ok,account,token}` · 401 si falla |
| `GET /api/me` | header `Authorization: Bearer <token>` | cuenta sin hash |
| `PUT /api/me` | `{name?,phone?,sizes?}` (talla `null` o `""` borra) | cuenta |
| `GET /api/codes/:code` | – | el código si está activo, si no 404 |

Admin (header `Authorization: Bearer <adminToken>`)
| Método y ruta | Notas |
|---|---|
| `POST /api/admin/login` `{user,password}` | devuelve `{ok,token}` |
| `GET /api/admin/accounts` | todas las cuentas, sin hash |
| `GET/POST /api/admin/products` | POST crea; el `id` se autogenera como `estilo-tipo-nombre` |
| `PUT /api/admin/products/:id` | edita; `{active:true}` = alta |
| `DELETE /api/admin/products/:id` | baja lógica (`active:false`) |
| `GET/POST /api/admin/codes` | POST crea (409 si ya existe) |
| `PUT /api/admin/codes/:code` | edita o `{active:true}` |
| `DELETE /api/admin/codes/:code` | baja lógica |

Estáticos: `/admin` sirve `admin.html`. Se bloquean con 404: `/data/*`, `/server.js`, cualquier archivo que empiece con `.` o `CONTRATO`. Cuerpo máximo de petición: 8 MB.

## 7. Tienda (frontend) en detalle

### Rutas (`#hash`)
| Hash | Pantalla |
|---|---|
| `#/` | Home: 5 estilos (hover/foco cambia la foto de ejemplo de la derecha), franja de modelos clicables |
| `#/estilo/:s` | Tipos de prenda (6 tarjetas con insignia "N piezas"), botón **Cambio de estilo** |
| `#/estilo/:s/:t` | Cortes de ese tipo en ese estilo |
| `#/estilo/:s/:t/:c` | Colores (casillas múltiples), "Comprar para alguien más" + talla, **Agregar al carrito** / **Comprar ahora** |
| `#/carrito` | Carrito |
| `#/perfil` | Perfil y tallas |

### Flujo de agregar
1. En la pantalla del corte se eligen uno o más colores (por defecto el primero).
2. **Agregar al carrito** → toast + si `hasAllTypes()` va a `#/carrito`, si no a `#/estilo/<estilo>`.
3. **Comprar ahora** → agrega y abre el carrito con el modal de compra ya abierto.
4. Si "para alguien más" está activo, la talla es **obligatoria** (mensaje "Indica la talla de la otra persona").

### Carrito
- Una tarjeta **por corte** (no por prenda). Dentro: chips con **todos** los colores del corte; el seleccionado se marca con ✓ y borde. Tocar agrega/quita (`Store.toggleColor`) sin cambiar de pantalla.
- Un corte cuyo último color se desmarca **permanece visible durante esa visita** al carrito (para poder volver a marcarlo); al salir de la pantalla desaparece.
- Por cada color elegido: casilla "Para alguien más" y la talla: `Talla M` (del perfil), o `Falta tu talla` + selector que la guarda al perfil, o selector obligatorio si es para otra persona.
- "Prendas recomendadas": hasta 4 piezas del tipo con menos piezas (empate → primero en el orden de `CATALOG.types`), del `lastStyle`, de cualquier corte, repartiendo cortes primero, excluyendo lo ya elegido. **Sin números de combinaciones.**
- Resumen: campo de código + Aplicar, etiqueta del descuento con "Quitar", Subtotal / Descuento / Total, botón Finalizar compra (deshabilitado con carrito vacío).
- Botón **← Volver a tipos de prenda** (a `#/estilo/<lastStyle o estilo del último ítem>`; si no hay, a `#/`).
- El campo de código se muestra **incluso con el carrito vacío** (para poder aplicar un código de atuendo).

### Modal de compra (`openCheckout`)
Pide solo las tallas que **faltan**: tipos sin talla en el perfil (piezas propias) y piezas "para alguien más" sin talla. Si hay sesión ofrece "Guardar estas tallas en mi perfil" (marcada por defecto); como invitado las tallas **no** se guardan en el perfil tras la compra. Confirmar → `Store.checkout()` → "¡Gracias por tu compra!".

### Inicio de sesión / perfil
- Modal con pestañas **Iniciar sesión** / **Crear cuenta** (nombre, correo, teléfono opcional, contraseña ≥ 6). Las tallas **no** se piden al registrarse.
- Con sesión, el botón de arriba a la izquierda muestra el nombre y lleva a `#/perfil`.
- Perfil: datos (solo lectura: **no hay edición de nombre/teléfono en la UI**, aunque `PUT /api/me` sí lo soporta), selectores de talla por tipo (guardan en el servidor al cambiar), "Cerrar sesión".
- `logout()` borra token, nombre, correo, teléfono y tallas locales (las tallas viven en la cuenta del servidor y regresan al volver a entrar). Esto fue un bug real corregido: antes las tallas de un usuario podían subirse a la cuenta de otro.

## 8. `Store` — API pública (`js/store.js`)

Estado en `localStorage` clave `tienda_v1`: `{cart, profile:{loggedIn,name,email,phone,token,sizes}, lastStyle, codes, discount}`.
Ítem del carrito: `{id:"<cutId>__<colorId>", styleId,typeId,cutId,colorId, forOther, size}` (una pieza = un corte + un color).

`subscribe(fn)`, `addItems(style,type,cut,colorIds[],{forOther,size})`, `removeItem(id)`, `toggleColor(style,type,cut,color)→{added}`, `setItemSize(id,size)`, `setForOther(id,bool)`, `clearCart()`, `countsByType()`, `hasAllTypes()`, `groupedCart()`, `recommendations(limit=4)`, `combinations()` *(solo interno)*, `effectiveSize(item)`, `missingSizesForCheckout()→{types,otherItems}`, `checkout()→{ok,order}` *(síncrono)*, `register(u)`/`login(u)` *(async→{ok,error})*, `logout()`, `refresh()`, `setProfileSize(type,size)`, `applyCode(code)` *(async)*, `removeDiscount()`, `totals()→{subtotal,discount,total}`.

Detalles que conviene saber:
- `login(u)` sin campo `password` es un **modo local heredado** (marca sesión sin servidor); la UI actual siempre manda contraseña.
- Si al cargar hay token guardado se llama `Store.refresh()` (`GET /api/me`); con 401/404 se cierra la sesión.
- `CATALOG.load()` pide `/api/catalog`; si falla **cae al catálogo generado** en `data.js` (por eso la tienda sigue viéndose aunque no haya backend; pero entonces registro/login/códigos fallan con "No se pudo conectar con el servidor").
- Descuento: `discount = round(subtotal * percent) / 100`, total redondeado a centavos.
- `applyCode` de atuendo: ignora piezas que ya estén o que ya no existan/color inválido; no falla si una pieza es inválida.

## 9. Seguridad: LEE ESTO antes de publicar

Lo implementado es suficiente para una demo/MVP, **no para producción abierta** sin endurecer:

1. **Contraseña de admin por defecto (`admin`/`admin123`).** Cámbiala con variables de entorno `ADMIN_USER` y `ADMIN_PASS` (usa una larga y aleatoria). Nunca la dejes por defecto en internet.
2. **Código basura en la base de datos local:** existe un código de atuendo `SOY-PUTO` (descripción "A", 1 pieza) en el `data/db.json` de la máquina del autor. No lo creó el desarrollo; **bórralo desde el admin (pestaña Códigos → Baja)** o elimina `data/db.json` para re-sembrar. El `db.json` NO va dentro del zip de entrega.
3. **Los tokens de sesión no expiran** y se guardan en `db.json`. Añade expiración y borra los viejos.
4. **Sin límite de intentos (rate limit)** en `/api/login` ni `/api/admin/login`: vulnerable a fuerza bruta. Añade límite por IP y/o retraso.
5. **Sin HTTPS propio:** el servidor habla HTTP. En producción pon un proxy/hosting con TLS (casi todos lo dan). Sin HTTPS, contraseñas y tokens viajan en claro.
6. **Sin CORS** (mismo origen): está bien si frontend y API se sirven juntos, como ahora.
7. **Imágenes subidas** se guardan como base64 dentro de `db.json` (hasta 5 MB cada una). Muchas imágenes inflarán el archivo y cada guardado reescribe todo. Para producción: sube a almacenamiento de objetos (S3/R2/Cloudinary) y guarda solo la URL.
8. **Las imágenes `svg+xml` subidas se aceptan** (`data:image/svg+xml`) y se muestran vía `<img>` (los scripts dentro de SVG no se ejecutan en `<img>`), pero si algún día se inserta ese SVG inline en el DOM habría riesgo de XSS. No lo hagas.
9. El frontend escapa el HTML con `esc()` en lo que renderiza; mantén esa disciplina si agregas pantallas.
10. **No hay protección CSRF** porque se usa header `Authorization` (no cookies). Si migras a cookies, añade protección.
11. Los datos personales (nombre, correo, teléfono) quedan en `db.json` en texto plano (salvo contraseña). Si vas a operar de verdad en México, necesitas aviso de privacidad (LFPDPPP).

## 10. CÓMO PUBLICAR (sin tocar tu otra página de Vercel)

**Regla de oro:** no importes esta carpeta al proyecto de Vercel existente, no uses el mismo nombre de proyecto ni pongas el mismo dominio. Tu otro sitio no se afecta mientras esto viva en **otro proyecto/otra plataforma**.

### Opción 1 (recomendada, funciona todo): hosting con servidor Node y disco persistente
Necesitas un lugar que ejecute `node server.js` **y** conserve la carpeta `data/` entre reinicios. Ejemplos: **Render** (Web Service + Disk), **Railway** (Volume), **Fly.io** (Volume), un VPS.

Pasos genéricos:
1. Sube el proyecto a un repositorio **nuevo** de GitHub (añade `.gitignore` con `data/` y `.DS_Store`).
2. Crea un servicio Node: *Build command* vacío, *Start command* `node server.js`.
3. Variables de entorno: `ADMIN_USER`, `ADMIN_PASS` (obligatorio cambiar). `PORT` lo inyecta la plataforma; `server.js` ya lo lee (`process.env.PORT`).
4. Monta un **disco/volumen persistente** y haz que `data/` viva ahí (monta el volumen en `<app>/data`). Sin esto se pierden cuentas y cambios en cada redeploy.
5. Si la plataforma escala a >1 instancia, **déjalo en 1**: la "base de datos" es un archivo, no soporta varias instancias.
6. Prueba: abrir `/`, registrar una cuenta, entrar a `/admin`, ver la cuenta, crear un producto con imagen.

### Opción 2: Vercel en un proyecto NUEVO (solo página estática, sin cuentas ni admin)
Sirve para mostrar el catálogo y el carrito, pero **no** registro/login/códigos/admin (Vercel serverless no guarda archivos).
- Archivos a subir: `index.html`, `css/app.css`, `js/data.js`, `js/store.js`, `js/app.js` (NO subir `server.js`, `admin.html`, `data/`).
- `vercel` → "Set up and deploy" → **nombre de proyecto nuevo y distinto**, framework "Other", sin build, directorio de salida `.`.
- Verifica en el panel de Vercel que el proyecto nuevo no esté enlazado a tu repo/proyecto anterior (la carpeta `.vercel/` decide a qué proyecto se sube: bórrala si la hay).

### Opción 3: reescribir el backend para Vercel/serverless
Si de verdad se quiere Vercel con todo funcionando: convertir `api()` de `server.js` en funciones serverless (`/api/*.js`) y reemplazar `db.json` por una base de datos (Vercel Postgres/Neon, Supabase, Turso, Upstash Redis) y las imágenes por un almacenamiento de objetos (Vercel Blob/S3). Es trabajo real (~1–2 días). La API ya está bien separada (sección 6) y el frontend no cambia.

## 11. Probado vs. no probado

**Probado en navegador con clics reales (agente verificador):** requisitos 1–13 y A–K de la sección 2, incluyendo: flujo completo estilo→tipo→corte→color→carrito; carrito automático con 1 pieza de cada tipo; colores del carrito agregan/quitan; registro/login/logout; persistencia de tallas entre sesiones; checkout pidiendo solo tallas faltantes; compra para otra persona exige talla; admin: ver cuenta con todos sus datos, crear producto con imagen subida, baja/alta reflejada en la tienda; códigos: `LOOK-DEMO` agrega 3 piezas, `DESC10` descuenta 10 %, editar `DESC10` a 25 % cambió el total de 888 a 666; código creado en admin funciona. Sin errores de consola salvo un 401 esperado de una llamada de sesión.
**Probado por curl (API):** registro, correo duplicado (409), contraseña incorrecta (401), tallas, CRUD de productos/códigos, admin sin token (401), porcentaje 99 rechazado (400), `/data/db.json` → 404.

## 12. Cómo se verificaría un cambio (checklist de regresión)

1. `node server.js` limpio (sin `data/`). Home carga, 5 estilos, 10 modelos en la franja.
2. Entrar a un estilo → 6 tipos → corte → 2 colores → Agregar. Debe volver a tipos con insignia.
3. Agregar 1 pieza de los 6 tipos → al agregar la sexta abre `#/carrito`.
4. En el carrito tocar un color apagado lo agrega; tocar uno encendido lo quita. No debe aparecer la palabra "combinaciones" ni "looks" en ningún lado.
5. Registrar cuenta, poner talla M en playeras en el perfil, cerrar sesión, volver a entrar → la talla M sigue. En el carrito dice "Talla M".
6. Finalizar compra: solo pide tallas de tipos sin talla.
7. `LOOK-DEMO` con carrito vacío agrega 3 piezas. `DESC10` descuenta 10 %.
8. Admin: la cuenta aparece; crear producto con imagen; darlo de baja → desaparece de la tienda; de alta → vuelve.

## 13. Cómo extender (guía rápida)

- **Nuevo producto/corte:** desde `/admin` → Productos (no requiere código).
- **Nuevo estilo o nuevo tipo de prenda:** editar `js/data.js` (`styles`, `types`, `sizes`, `cutDefs`, `colorNames`, `styleMult`, y `labels` de la galería), **borrar `data/db.json`** para re-sembrar (o añadir los productos por admin; ojo: `CATALOG.load()` descarta productos cuyo `styleId`/`typeId` no existan en `data.js`). También el panel admin lee estilos/tipos de `js/data.js` (`admin.html` lo carga).
- **Fotos reales de estilos/modelos del home:** hoy son ilustraciones SVG generadas por `imgSVG`. Cambiar `pageHome()`/`setPreview()` para usar `<img src="/img/...">` y `CATALOG.gallery` con campo `image`.
- **Pedidos reales/pagos:** `Store.checkout()` es síncrono y local. Habría que crear `POST /api/orders` (guardar pedido ligado a la cuenta), mostrar pedidos en el admin y conectar una pasarela (Stripe/Mercado Pago/Conekta).
- **Editar nombre/teléfono en el perfil:** `PUT /api/me` ya lo soporta; falta el formulario en `pageProfile()`.
- **Recuperar contraseña / verificar correo:** no existe.

## 14. Limitaciones y pendientes conocidos (honestidad total)

- **El PDF del cliente ("No se que valla dares a resultar.pdf") NO se pudo leer** (faltaba `poppler`/`pdftoppm` en la Mac). Todo se construyó con el texto que el cliente escribió en el chat. **Antes de dar por cerrado el proyecto, alguien debe leer ese PDF** (contexto del producto) y contrastar con la sección 2.
- **No se probó en móvil** (solo se revisó el CSS responsive: breakpoints 860 px y 520 px).
- **Las "fotos" son ilustraciones SVG**, no fotografías reales.
- **No hay pedidos persistentes ni pagos:** comprar no guarda nada.
- **La interfaz usa el catálogo del servidor; si el servidor cae, la tienda se ve pero sin cuentas/códigos.**
- Tokens sin expiración, sin rate-limit, base de datos de un solo archivo con una sola instancia (sección 9).
- `data/db.json` se reescribe completo en cada cambio (escritura atómica con archivo temporal + `rename`). Con mucho tráfico o muchas imágenes base64 será lento.
- Las tallas de un usuario se **fusionan** al iniciar sesión: las del servidor mandan; las locales que el servidor no tenga se suben.
- En el panel admin las cuentas son de solo lectura (no hay borrar/editar/exportar cuentas).
- Admin: no hay edición de estilos/tipos (están en código) ni de la galería del home.
- Registros de pruebas anteriores fueron limpiados; la base entregada no incluye cuentas.

## 15. Historia del desarrollo (por si preguntan "por qué está así")

Se construyó con varios agentes en paralelo siguiendo contratos escritos (`CONTRATO.md`, `CONTRATO2.md`): un agente para datos, otro para la lógica del carrito y otro para la interfaz/servidor; después un agente "maestro" probó todo en navegador y corrigió fallos. Los contratos explican el porqué de la separación `data.js` / `store.js` / `app.js`. Son útiles de referencia pero **el código es la fuente de verdad**.

## 16. Entrega (qué recibe quien continúe)

1. La carpeta del proyecto (zip `tienda-estilos.zip`), sin `data/` ni `db.json`.
2. Este `HANDOFF.md`.
3. Credenciales: **no** se entregan en este documento más que las de prueba (`admin`/`admin123`). El dueño debe definir las reales.
4. Lo primero que debe hacer quien reciba esto: leer el PDF del cliente (sección 14), correr en local (sección 3), cambiar la contraseña de admin (sección 9), elegir hosting (sección 10).

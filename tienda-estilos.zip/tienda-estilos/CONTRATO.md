# Contrato (tienda de ropa por estilos, SPA vanilla, sin build, servida en localhost)

Archivos: index.html, css/app.css, js/data.js, js/store.js, js/app.js, server.js (ya existe lo hace el maestro). Idioma UI: español.

## js/data.js  -> window.CATALOG
- `CATALOG.styles`: 5 estilos `{id, name, tagline, colors:[c1,c2,c3]}` ids: `streetwear`,`minimal`,`vintage`,`deportivo`,`elegante`.
- `CATALOG.types`: 6 tipos `{id,name}` ids: `playeras`,`pantalones`,`zapatos`,`sudaderas`,`chamarras`,`accesorios`.
- `CATALOG.getCuts(styleId,typeId)` -> array de 3-4 cortes `{id, name, price, colors:[{id,name,hex}]}` (3-5 colores c/u). Ej. pantalones: Corte recto, Skinny, Baggy, Cargo. Determinista; ids únicos globales (`${style}-${type}-${cut}`).
- `CATALOG.getCut(styleId,typeId,cutId)`, `CATALOG.type(id)`, `CATALOG.style(id)`.
- `CATALOG.gallery`: 10 modelos `{id, styleId, label}` (2 por estilo) para la franja inferior del home.
- `window.imgSVG(label, c1, c2, kind)` -> data URI SVG con una ilustración/“foto” aesthetic (gradiente + silueta simple de prenda según kind: 'model'|'playeras'|... ) usable en <img src>. Sin imágenes externas.
- `CATALOG.sizes`: por tipo lista de tallas (ropa XS-XXL; zapatos 24-30; accesorios ['Única']).

## js/store.js -> window.Store (estado en localStorage clave `tienda_v1`)
Ítem de carrito: `{id, styleId, typeId, cutId, colorId, forOther:boolean, size:string|null}` (una pieza = un corte+color).
- `Store.state` `{cart:[], profile:{loggedIn,name,email,sizes:{[typeId]:size}}, lastStyle}`; `Store.subscribe(fn)`; cambios llaman fn.
- `addItems(styleId,typeId,cutId,colorIds[],opts)` (ignora duplicados), `removeItem(id)`, `setItemSize(id,size)`, `setForOther(id,bool)`, `clearCart()`.
- `countsByType()` -> `{typeId:n}` para los 6 tipos (0 si no hay).
- `combinations()` -> producto de max(1,n) sobre los 6 tipos.
- `hasAllTypes()` -> true si n>=1 en los 6 tipos.
- `groupedCart()` -> `[{styleId,typeId,cutId,items:[...],colorIds:[...]}]` agrupado por estilo+tipo+corte.
- `recommendations(limit=4)` -> tipo con MENOS piezas (empate: orden de CATALOG.types); estilo = `lastStyle` o el del último ítem; produce piezas de ese tipo, de cualquier corte, que no estén ya en el carrito: `{styleId,typeId,cutId,colorId,name,price,newCombos,diff}` donde `diff = combinations si se agrega - combinations actual`.
- `login({name,email})`, `logout()`, `setProfileSize(typeId,size)`.
- `missingSizesForCheckout()` -> tipos en carrito de ítems `!forOther` sin talla en perfil; ítems forOther sin `size` se reportan aparte: `{types:[typeId], otherItems:[itemId]}`.
- `checkout()` -> falla si falta talla; guarda tallas en perfil, vacía carrito, devuelve `{ok,order}`.

## js/app.js (UI, hash router)
Rutas: `#/` home, `#/estilo/:s` (filtro 2 tipos), `#/estilo/:s/:t` (cortes), `#/estilo/:s/:t/:c` (colores + botones “Agregar al carrito” y “Comprar ahora” + toggle “Comprar para alguien más”), `#/carrito`, `#/perfil`.
Reglas de flujo (del cliente):
1. Home: fondo aesthetic, 5 estilos a la izquierda, a la derecha foto de ejemplo del estilo (cambia con hover/selección), debajo franja de modelos clicables que abre ese estilo. Botón “Iniciar sesión” arriba izquierda, botón “Carrito” (con contador) abajo izquierda, fijo en TODAS las pantallas.
2. Tras agregar al carrito: si `hasAllTypes()` -> ir a `#/carrito`; si no -> volver a `#/estilo/:s` (tipos) mostrando insignia con cuántas piezas hay por tipo.
3. Carrito: muestra por corte elegido con los colores palomeados (checkbox, desmarcar quita), NO prenda por prenda. Muestra desglose y total de combinaciones con la fórmula (n1 × n2 × … con mínimo 1). Sección “Prendas recomendadas” con la diferencia “+N combinaciones”. Si “para alguien más” está activo en una pieza, pedir talla obligatoria en esa pieza.
4. Perfil: correo, nombre, tallas por tipo (no obligatorias para iniciar sesión; se piden al comprar cada tipo).
5. Comprar ahora/finalizar: modal que pide tallas faltantes; funciona sin sesión (invitado) pero ofrece guardarlas si hay sesión.
Todo el DOM se genera desde JS; sin librerías externas.

## css/app.css + index.html
Estética oscura/aesthetic, tipografía del sistema, responsive, botones fijos `#btn-login` (top-left) y `#btn-cart` (bottom-left). index.html contiene `<div id="app">`, esos dos botones y carga los scripts en orden data, store, app.
